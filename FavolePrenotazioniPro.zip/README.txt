FAVOLE DI PANE - PRENOTAZIONI PRO

CONTENUTO
- index.html
- cartella assets per le foto reali del locale

COME METTERE LE FOTO DEL LOCALE
Sostituisci o aggiungi nella cartella assets queste immagini:

1. locale-hero.jpg    = foto principale grande in apertura
2. locale-1.jpg       = foto sala principale
3. locale-2.jpg       = foto banco / bistrot
4. apericena.jpg      = foto apericena / drink / tavolo

IMPORTANTE:
Mantieni esattamente questi nomi file.
Se una foto manca, il sito usa una foto online provvisoria.

COME INSERIRE WHATSAPP
Apri index.html e cerca:

window.FAVOLE_WHATSAPP_NUMBER = "393XXXXXXXXX";

Sostituisci con il numero del locale senza + e senza spazi.
Esempio:

window.FAVOLE_WHATSAPP_NUMBER = "393491234567";

EMAIL AUTOMATICA AL CLIENTE
Il sito ha già il campo email.
Per inviare davvero una mail automatica dal sito statico ti serve un servizio esterno.

Metodo semplice consigliato:
- EmailJS
- Formspree
- Make/Zapier
- Netlify Forms + funzione automatica

Nel file ho predisposto EmailJS.

Per attivarlo:
1. Vai su emailjs.com
2. Crea un account
3. Crea un Email Service
4. Crea un Template
5. Inserisci nel template questi campi:
   {{nome}}
   {{email}}
   {{telefono}}
   {{tipo}}
   {{fascia}}
   {{persone}}
   {{data}}
   {{ora}}
   {{zona}}
   {{note}}
6. In index.html metti:

window.ENABLE_EMAILJS = true;
window.EMAILJS_PUBLIC_KEY = "la_tua_public_key";
window.EMAILJS_SERVICE_ID = "il_tuo_service_id";
window.EMAILJS_TEMPLATE_ID = "il_tuo_template_id";

BOT AUTOMATICO WHATSAPP
Un sito statico NON può rispondere automaticamente su WhatsApp da solo.

Per avere un vero bot automatico devi usare:
- WhatsApp Business Cloud API di Meta
- Twilio WhatsApp
- WATI
- Manychat
- Make/Zapier collegato a WhatsApp Business API

Il sito però è già pronto:
- raccoglie nome, telefono, email, data, ora, persone e note
- apre WhatsApp con messaggio ordinato
- può inviare email automatica se configuri EmailJS

PUBBLICAZIONE
Carica tutto su GitHub o Netlify:
- index.html
- cartella assets
