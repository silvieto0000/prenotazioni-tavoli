La foto caricata è stata rinominata in assets/locale-hero.jpg.
Sostituisci il file omonimo del progetto con questo per usarla come immagine principale.